from package.userInterface import UserInterface

if __name__=='__main__':
    interface = UserInterface()
    interface.run()