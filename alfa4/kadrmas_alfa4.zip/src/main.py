from package.peer import Peer

if __name__=="__main__":
    Peer()