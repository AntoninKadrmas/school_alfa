import unittest,json 
from loadConfigTest import LoadConfigTest,LoadConfigSingletonTest
from loadDictionaryTest import LoadDictionarySingletonTest,LoadDictionaryTest
from commandTest import CommandTest
if __name__ == '__main__':
    unittest.main()